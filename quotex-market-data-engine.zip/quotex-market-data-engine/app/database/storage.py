"""SQLite persistence for candles and the supported-asset list.

A fresh connection is opened per operation, which keeps the class safe to call from worker threads
(the async layer uses ``asyncio.to_thread``). WAL mode lets readers and the collector coexist.
"""
from __future__ import annotations

import logging
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional, Sequence

from app.market.models import Asset, Candle, Timeframe

logger = logging.getLogger(__name__)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS candles (
    asset      TEXT    NOT NULL,
    timeframe  TEXT    NOT NULL,
    ts         INTEGER NOT NULL,          -- candle open time, UTC epoch seconds
    open       REAL    NOT NULL,
    high       REAL    NOT NULL,
    low        REAL    NOT NULL,
    close      REAL    NOT NULL,
    volume     REAL,
    source     TEXT    NOT NULL,          -- which provider supplied this row
    fetched_at INTEGER NOT NULL,          -- when we received it, UTC epoch seconds
    PRIMARY KEY (asset, timeframe, ts)
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS assets (
    symbol      TEXT PRIMARY KEY,
    base        TEXT NOT NULL,
    quote       TEXT NOT NULL,
    asset_group TEXT,
    source      TEXT NOT NULL,
    updated_at  INTEGER NOT NULL
);
"""


class StorageError(Exception):
    """The database could not be opened, read or written."""


def _to_epoch(value: datetime) -> int:
    return int(value.timestamp())


def _from_epoch(value: int) -> datetime:
    return datetime.fromtimestamp(value, tz=timezone.utc)


class SQLiteStorage:
    def __init__(self, path: str) -> None:
        self.path = path
        if path != ":memory:":
            try:
                Path(path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                raise StorageError(f"cannot create database directory for {path!r}: {exc}") from exc

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        try:
            conn = sqlite3.connect(self.path, timeout=10.0)
        except sqlite3.Error as exc:
            raise StorageError(f"cannot open database {self.path!r}: {exc}") from exc
        try:
            conn.row_factory = sqlite3.Row
            yield conn
            conn.commit()
        except sqlite3.Error as exc:
            conn.rollback()
            raise StorageError(f"database error: {exc}") from exc
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    # ------------------------------------------------------------------ setup / health

    def initialize(self) -> None:
        """Create tables if they do not exist. Safe to call repeatedly."""
        with self._connect() as conn:
            try:
                conn.execute("PRAGMA journal_mode=WAL")
            except sqlite3.Error:  # e.g. some network filesystems; carry on without WAL
                logger.warning("Could not enable WAL mode for %s", self.path)
            conn.executescript(_SCHEMA)

    def ping(self) -> None:
        with self._connect() as conn:
            conn.execute("SELECT 1").fetchone()

    # ------------------------------------------------------------------ candles

    def upsert_candles(self, candles: Sequence[Candle]) -> int:
        """Insert new candles and update existing ones (the forming candle changes over time)."""
        if not candles:
            return 0
        rows = [
            (
                c.asset,
                c.timeframe.value,
                _to_epoch(c.timestamp),
                c.open,
                c.high,
                c.low,
                c.close,
                c.volume,
                c.source,
                _to_epoch(c.fetched_at),
            )
            for c in candles
        ]
        with self._connect() as conn:
            conn.executemany(
                """
                INSERT INTO candles
                    (asset, timeframe, ts, open, high, low, close, volume, source, fetched_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(asset, timeframe, ts) DO UPDATE SET
                    open = excluded.open,
                    high = excluded.high,
                    low = excluded.low,
                    close = excluded.close,
                    volume = excluded.volume,
                    source = excluded.source,
                    fetched_at = excluded.fetched_at
                """,
                rows,
            )
        return len(rows)

    def get_candles(
        self,
        asset: str,
        timeframe: Timeframe,
        limit: int,
        *,
        closed_only: bool = False,
        now: Optional[datetime] = None,
    ) -> list[Candle]:
        """Return the most recent ``limit`` candles, ordered oldest-first."""
        sql = "SELECT * FROM candles WHERE asset = ? AND timeframe = ?"
        params: list[object] = [asset, timeframe.value]
        if closed_only:
            cutoff = _to_epoch(now or datetime.now(timezone.utc)) - timeframe.seconds
            sql += " AND ts <= ?"
            params.append(cutoff)
        sql += " ORDER BY ts DESC LIMIT ?"
        params.append(limit)

        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()

        candles: list[Candle] = []
        for row in reversed(rows):
            try:
                candles.append(
                    Candle(
                        asset=row["asset"],
                        timeframe=Timeframe(row["timeframe"]),
                        timestamp=_from_epoch(row["ts"]),
                        open=row["open"],
                        high=row["high"],
                        low=row["low"],
                        close=row["close"],
                        volume=row["volume"],
                        source=row["source"],
                        fetched_at=_from_epoch(row["fetched_at"]),
                    )
                )
            except ValueError as exc:
                logger.warning(
                    "Skipping corrupt stored candle %s %s ts=%s: %s",
                    row["asset"],
                    row["timeframe"],
                    row["ts"],
                    exc,
                )
        return candles

    def latest_fetched_at(self, asset: str, timeframe: Timeframe) -> Optional[datetime]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT MAX(fetched_at) AS latest FROM candles WHERE asset = ? AND timeframe = ?",
                (asset, timeframe.value),
            ).fetchone()
        return _from_epoch(row["latest"]) if row and row["latest"] is not None else None

    def count_candles(
        self, asset: Optional[str] = None, timeframe: Optional[Timeframe] = None
    ) -> int:
        sql = "SELECT COUNT(*) AS n FROM candles WHERE 1=1"
        params: list[object] = []
        if asset is not None:
            sql += " AND asset = ?"
            params.append(asset)
        if timeframe is not None:
            sql += " AND timeframe = ?"
            params.append(timeframe.value)
        with self._connect() as conn:
            return int(conn.execute(sql, params).fetchone()["n"])

    # ------------------------------------------------------------------ assets

    def upsert_assets(self, assets: Sequence[Asset], now: Optional[datetime] = None) -> int:
        """Replace the stored asset list with the provider's current list."""
        if not assets:
            return 0
        stamp = _to_epoch(now or datetime.now(timezone.utc))
        rows = [(a.symbol, a.base, a.quote, a.group, a.source, stamp) for a in assets]
        with self._connect() as conn:
            conn.execute("DELETE FROM assets")
            conn.executemany(
                "INSERT INTO assets (symbol, base, quote, asset_group, source, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                rows,
            )
        return len(rows)

    def get_assets(self) -> tuple[list[Asset], Optional[datetime]]:
        """Return stored assets (sorted by symbol) and when they were last refreshed."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT symbol, base, quote, asset_group, source, updated_at "
                "FROM assets ORDER BY symbol"
            ).fetchall()
        if not rows:
            return [], None
        assets = [
            Asset(
                symbol=r["symbol"],
                base=r["base"],
                quote=r["quote"],
                group=r["asset_group"],
                source=r["source"],
            )
            for r in rows
        ]
        return assets, _from_epoch(max(r["updated_at"] for r in rows))
