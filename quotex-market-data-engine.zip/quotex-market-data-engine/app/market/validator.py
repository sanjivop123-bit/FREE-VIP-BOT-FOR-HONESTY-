"""Validation of market data coming from a provider.

Nothing here invents or repairs data: a candle is either valid and kept, or rejected with a reason.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Optional, Sequence

from pydantic import ValidationError

from app.market.models import Candle, RawCandle, Timeframe

# Candle open times may not be in the future (allowing for small clock differences).
MAX_FUTURE_SKEW = timedelta(seconds=120)

_ASSET_RE = re.compile(r"^[A-Z0-9]{2,10}/[A-Z0-9]{2,10}$")
_EPOCH_RE = re.compile(r"^\d{9,13}(\.\d+)?$")


def normalize_asset(value: Any) -> str:
    """Return a canonical ``BASE/QUOTE`` symbol or raise ValueError.

    Accepts ``eur/usd``, ``EURUSD``, ``EUR-USD`` and ``EUR_USD``.
    """
    if not isinstance(value, str):
        raise ValueError("asset must be a string")
    cleaned = value.strip().upper().replace("-", "/").replace("_", "/").replace(" ", "")
    if "/" not in cleaned and len(cleaned) == 6 and cleaned.isalpha():
        cleaned = f"{cleaned[:3]}/{cleaned[3:]}"
    if not _ASSET_RE.match(cleaned):
        raise ValueError(f"invalid asset symbol: {value!r} (expected e.g. EUR/USD)")
    return cleaned


def _from_epoch(seconds: float) -> datetime:
    if not math.isfinite(seconds) or seconds <= 0:
        raise ValueError("timestamp out of range")
    if seconds > 1e11:  # milliseconds
        seconds /= 1000.0
    try:
        return datetime.fromtimestamp(seconds, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        raise ValueError("timestamp out of range") from None


def parse_timestamp(value: Any) -> datetime:
    """Parse a timestamp into an aware UTC datetime. Naive values are treated as UTC."""
    if value is None or isinstance(value, bool):
        raise ValueError("timestamp is missing")
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, (int, float)):
        parsed = _from_epoch(float(value))
    elif isinstance(value, str):
        text = value.strip()
        if not text:
            raise ValueError("timestamp is empty")
        if _EPOCH_RE.match(text):
            parsed = _from_epoch(float(text))
        else:
            try:
                parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
            except ValueError:
                raise ValueError(f"unparseable timestamp {text!r}") from None
    else:
        raise ValueError(f"unsupported timestamp type {type(value).__name__}")
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def parse_number(value: Any, name: str) -> float:
    """Parse a finite float from a number or numeric string."""
    if value is None or isinstance(value, bool):
        raise ValueError(f"{name} is missing")
    if isinstance(value, str):
        value = value.strip()
        if not value:
            raise ValueError(f"{name} is empty")
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{name} is not numeric: {value!r}") from None
    if not math.isfinite(number):
        raise ValueError(f"{name} is not finite")
    return number


def validate_candle(
    raw: RawCandle,
    *,
    asset: str,
    timeframe: Timeframe,
    source: str,
    fetched_at: datetime,
    now: datetime,
) -> Candle:
    """Validate one raw candle. Raises ValueError with a human-readable reason."""
    timestamp = parse_timestamp(raw.timestamp)
    if timestamp > now + MAX_FUTURE_SKEW:
        raise ValueError(f"timestamp {timestamp.isoformat()} is in the future")
    if timestamp.microsecond or int(timestamp.timestamp()) % timeframe.seconds != 0:
        raise ValueError(
            f"timestamp {timestamp.isoformat()} is not aligned to a {timeframe.value} boundary"
        )

    o = parse_number(raw.open, "open")
    h = parse_number(raw.high, "high")
    low = parse_number(raw.low, "low")
    c = parse_number(raw.close, "close")
    for name, price in (("open", o), ("high", h), ("low", low), ("close", c)):
        if price <= 0:
            raise ValueError(f"{name} must be greater than zero (got {price})")
    if h < low:
        raise ValueError(f"high ({h}) is below low ({low})")
    if h < max(o, c):
        raise ValueError("high is below open/close")
    if low > min(o, c):
        raise ValueError("low is above open/close")

    volume: Optional[float] = None
    if raw.volume is not None and raw.volume != "":
        volume = parse_number(raw.volume, "volume")
        if volume < 0:
            raise ValueError("volume is negative")

    try:
        return Candle(
            asset=asset,
            timeframe=timeframe,
            timestamp=timestamp,
            open=o,
            high=h,
            low=low,
            close=c,
            volume=volume,
            source=source,
            fetched_at=fetched_at,
        )
    except ValidationError as exc:  # safety net; the checks above should catch everything
        raise ValueError(f"model validation failed: {exc.errors()[0]['msg']}") from exc


@dataclass(frozen=True)
class RejectedCandle:
    index: int
    reason: str


@dataclass
class ValidationReport:
    valid: list[Candle] = field(default_factory=list)
    rejected: list[RejectedCandle] = field(default_factory=list)


def validate_candles(
    raw_candles: Sequence[RawCandle],
    *,
    asset: str,
    timeframe: Timeframe,
    source: str,
    fetched_at: Optional[datetime] = None,
    now: Optional[datetime] = None,
) -> ValidationReport:
    """Validate a batch. Returns valid candles (sorted oldest-first, de-duplicated) and rejects."""
    now = now or datetime.now(timezone.utc)
    fetched_at = fetched_at or now
    by_timestamp: dict[datetime, Candle] = {}
    rejected: list[RejectedCandle] = []
    for index, raw in enumerate(raw_candles):
        try:
            candle = validate_candle(
                raw,
                asset=asset,
                timeframe=timeframe,
                source=source,
                fetched_at=fetched_at,
                now=now,
            )
        except ValueError as exc:
            rejected.append(RejectedCandle(index=index, reason=str(exc)))
            continue
        by_timestamp[candle.timestamp] = candle  # a later duplicate replaces an earlier one
    valid = sorted(by_timestamp.values(), key=lambda candle: candle.timestamp)
    return ValidationReport(valid=valid, rejected=rejected)
