"""Orchestrates provider -> validator -> storage, and serves reads from storage.

Guarantees:
  * Only validated candles are stored.
  * If the provider fails, previously stored candles may be returned, but are flagged ``stale``.
  * No data is ever generated locally.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Optional

from app.config import Settings
from app.database.storage import SQLiteStorage, StorageError
from app.market.models import Asset, Candle, Timeframe
from app.market.provider import (
    InvalidAssetError,
    MarketDataError,
    MarketDataProvider,
    ProviderDataError,
    ProviderError,
    ProviderRateLimitError,
    UnknownAssetError,
    UnsupportedTimeframeError,
)
from app.market.validator import normalize_asset, validate_candles

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class CollectResult:
    asset: str
    timeframe: Timeframe
    received: int
    accepted: int
    rejected: int
    stored: int


@dataclass
class AssetListResult:
    assets: list[Asset]
    stale: bool
    updated_at: Optional[datetime]


@dataclass
class CandlesResult:
    asset: str
    timeframe: Timeframe
    candles: list[Candle]
    source: Optional[str]
    stale: bool
    warnings: list[str] = field(default_factory=list)


class MarketCollector:
    def __init__(
        self,
        provider: MarketDataProvider,
        storage: SQLiteStorage,
        settings: Settings,
        *,
        clock: Callable[[], datetime] = _utcnow,
    ) -> None:
        self._provider = provider
        self._storage = storage
        self._settings = settings
        self._clock = clock
        self._assets_lock = asyncio.Lock()

    # ------------------------------------------------------------------ assets

    async def get_assets(self, *, force_refresh: bool = False) -> AssetListResult:
        """Supported assets: cached in SQLite, refreshed when older than the TTL."""
        async with self._assets_lock:
            stored, updated_at = await asyncio.to_thread(self._storage.get_assets)
            now = self._clock()
            fresh = (
                updated_at is not None
                and (now - updated_at).total_seconds() < self._settings.assets_cache_ttl_seconds
            )
            if stored and fresh and not force_refresh:
                return AssetListResult(stored, False, updated_at)
            try:
                assets = await self._provider.list_assets()
            except ProviderError as exc:
                if stored:
                    logger.warning("Asset refresh failed (%s); serving stored list", exc.message)
                    return AssetListResult(stored, True, updated_at)
                raise
            await asyncio.to_thread(self._storage.upsert_assets, assets, now)
            return AssetListResult(assets, False, now)

    # ------------------------------------------------------------------ candles

    def _normalize(self, asset: str) -> str:
        try:
            return normalize_asset(asset)
        except ValueError as exc:
            raise InvalidAssetError(str(exc)) from exc

    def _ensure_supported(self, timeframe: Timeframe) -> None:
        if timeframe not in self._provider.supported_timeframes:
            supported = ", ".join(sorted(t.value for t in self._provider.supported_timeframes))
            raise UnsupportedTimeframeError(
                f"Provider {self._provider.name!r} does not support {timeframe.value}. "
                f"Supported: {supported}"
            )

    async def _ensure_known_asset(self, symbol: str) -> None:
        """Reject symbols the provider does not offer, saving a wasted API call."""
        try:
            result = await self.get_assets()
        except MarketDataError as exc:
            logger.warning("Cannot verify %s against the asset list: %s", symbol, exc.message)
            return
        if symbol not in {asset.symbol for asset in result.assets}:
            raise UnknownAssetError(
                f"Asset {symbol!r} is not offered by provider {self._provider.name!r}. "
                "See GET /assets for the supported list."
            )

    async def collect(self, asset: str, timeframe: Timeframe, limit: int) -> CollectResult:
        """Fetch from the provider, validate, and store. Raises on provider failure."""
        symbol = self._normalize(asset)
        self._ensure_supported(timeframe)

        raw = await self._provider.fetch_candles(symbol, timeframe, limit)
        fetched_at = self._clock()
        report = validate_candles(
            raw,
            asset=symbol,
            timeframe=timeframe,
            source=self._provider.name,
            fetched_at=fetched_at,
            now=fetched_at,
        )
        if report.rejected:
            logger.warning(
                "Rejected %d of %d candles for %s %s; first reason: %s",
                len(report.rejected),
                len(raw),
                symbol,
                timeframe.value,
                report.rejected[0].reason,
            )
        if raw and not report.valid:
            raise ProviderDataError(
                f"All {len(raw)} candles from {self._provider.name} failed validation "
                f"(e.g. {report.rejected[0].reason})"
            )
        if not raw:
            logger.warning("Provider returned no candles for %s %s", symbol, timeframe.value)

        stored = await asyncio.to_thread(self._storage.upsert_candles, report.valid)
        return CollectResult(
            asset=symbol,
            timeframe=timeframe,
            received=len(raw),
            accepted=len(report.valid),
            rejected=len(report.rejected),
            stored=stored,
        )

    async def get_candles(
        self,
        asset: str,
        timeframe: Timeframe,
        limit: int,
        *,
        refresh: bool = True,
        closed_only: bool = False,
    ) -> CandlesResult:
        """Latest candles, oldest-first.

        With ``refresh`` the provider is asked for fresh data unless this asset/timeframe was
        fetched within CANDLES_CACHE_TTL_SECONDS. If the refresh fails but stored candles exist,
        they are returned with ``stale=True``; with nothing stored the error is raised.
        """
        symbol = self._normalize(asset)
        self._ensure_supported(timeframe)
        await self._ensure_known_asset(symbol)

        warnings: list[str] = []
        provider_error: Optional[ProviderError] = None

        if refresh:
            last = await asyncio.to_thread(self._storage.latest_fetched_at, symbol, timeframe)
            age = (self._clock() - last).total_seconds() if last is not None else None
            if age is None or age >= self._settings.candles_cache_ttl_seconds:
                # The newest candle is usually still forming, so ask for one extra when the
                # caller wants closed candles only; they then get `limit` of them.
                fetch_limit = limit + 1 if closed_only else limit
                try:
                    await self.collect(symbol, timeframe, fetch_limit)
                except ProviderError as exc:
                    provider_error = exc
                    logger.warning(
                        "Refresh failed for %s %s: %s %s",
                        symbol,
                        timeframe.value,
                        exc.code,
                        exc.message,
                    )
                    warnings.append(
                        f"Live refresh failed ({exc.code}): {exc.message} "
                        "Returning previously stored candles."
                    )

        candles = await asyncio.to_thread(
            self._storage.get_candles,
            symbol,
            timeframe,
            limit,
            closed_only=closed_only,
            now=self._clock(),
        )
        if provider_error is not None and not candles:
            raise provider_error
        if not candles:
            warnings.append(
                "No stored candles for this asset/timeframe yet."
                + ("" if refresh else " Retry with refresh=true.")
            )

        source = ",".join(sorted({c.source for c in candles})) or None
        return CandlesResult(
            asset=symbol,
            timeframe=timeframe,
            candles=candles,
            source=source,
            stale=provider_error is not None,
            warnings=warnings,
        )

    # ------------------------------------------------------------------ background polling

    async def _collector_symbols(self) -> list[str]:
        configured = self._settings.collector_assets
        if configured == ("ALL",):
            result = await self.get_assets()
            return [asset.symbol for asset in result.assets]
        return list(configured)

    async def run_cycle(self, last_bucket: dict[tuple[str, Timeframe], int]) -> int:
        """One polling pass. Each (asset, timeframe) is fetched once per candle period.

        ``last_bucket`` remembers which period was last fetched successfully, so a 15-minute
        series is requested once per 15 minutes rather than every cycle. Returns the number of
        successful fetches.
        """
        try:
            symbols = await self._collector_symbols()
        except MarketDataError as exc:
            logger.error("Collector cannot determine assets to poll: %s", exc.message)
            return 0

        successes = 0
        for symbol in symbols:
            for timeframe in self._settings.collector_timeframes:
                if timeframe not in self._provider.supported_timeframes:
                    continue
                bucket = int(self._clock().timestamp()) // timeframe.seconds
                key = (symbol, timeframe)
                if last_bucket.get(key) == bucket:
                    continue
                try:
                    result = await self.collect(
                        symbol, timeframe, self._settings.collector_outputsize
                    )
                except ProviderRateLimitError as exc:
                    wait = min(exc.retry_after or 60.0, 120.0)
                    logger.warning("Collector hit the rate limit; pausing %.0fs", wait)
                    await asyncio.sleep(wait)
                    continue
                except (MarketDataError, StorageError) as exc:
                    logger.error(
                        "Collector failed for %s %s: %s",
                        symbol,
                        timeframe.value,
                        getattr(exc, "message", str(exc)),
                    )
                except Exception:  # keep the loop alive no matter what
                    logger.exception("Unexpected collector error for %s %s", symbol, timeframe.value)
                else:
                    last_bucket[key] = bucket
                    successes += 1
                    logger.info(
                        "Collected %s %s: %d stored, %d rejected",
                        symbol,
                        timeframe.value,
                        result.stored,
                        result.rejected,
                    )
                await asyncio.sleep(self._settings.collector_request_delay_seconds)
        return successes

    async def run_forever(self) -> None:
        """Background loop started by the application when COLLECTOR_ENABLED=true."""
        if not self._settings.collector_assets:
            logger.warning("COLLECTOR_ENABLED is true but COLLECTOR_ASSETS is empty; nothing to poll")
        logger.info(
            "Background collector started (assets=%s, timeframes=%s, cycle=%.0fs)",
            ",".join(self._settings.collector_assets) or "-",
            ",".join(t.value for t in self._settings.collector_timeframes),
            self._settings.collector_cycle_seconds,
        )
        last_bucket: dict[tuple[str, Timeframe], int] = {}
        while True:
            started = time.monotonic()
            try:
                await self.run_cycle(last_bucket)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Collector cycle crashed; continuing")
            elapsed = time.monotonic() - started
            await asyncio.sleep(max(1.0, self._settings.collector_cycle_seconds - elapsed))
