"""Data models shared across the market-data engine."""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    computed_field,
    field_validator,
    model_validator,
)


class Timeframe(str, Enum):
    """Supported candle timeframes."""

    M1 = "1m"
    M5 = "5m"
    M15 = "15m"

    @property
    def seconds(self) -> int:
        return _TIMEFRAME_SECONDS[self]


_TIMEFRAME_SECONDS = {Timeframe.M1: 60, Timeframe.M5: 300, Timeframe.M15: 900}


@dataclass(frozen=True)
class RawCandle:
    """A candle exactly as a provider reported it, before validation.

    Values may be strings, numbers or None; the validator decides whether they are usable.
    """

    timestamp: Any
    open: Any
    high: Any
    low: Any
    close: Any
    volume: Any = None


class Candle(BaseModel):
    """A validated OHLC candle. ``timestamp`` is the candle OPEN time in UTC."""

    model_config = ConfigDict(frozen=True)

    asset: str
    timeframe: Timeframe
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: Optional[float] = None
    source: str
    fetched_at: datetime

    @field_validator("timestamp", "fetched_at")
    @classmethod
    def _utc_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("datetime must be timezone-aware")
        return value.astimezone(timezone.utc)

    @model_validator(mode="after")
    def _check_ohlc(self) -> "Candle":
        prices = (self.open, self.high, self.low, self.close)
        if not all(math.isfinite(p) and p > 0 for p in prices):
            raise ValueError("prices must be finite and greater than zero")
        if self.high < max(self.open, self.close, self.low):
            raise ValueError("high is below open, close or low")
        if self.low > min(self.open, self.close, self.high):
            raise ValueError("low is above open, close or high")
        return self

    @computed_field  # type: ignore[prop-decorator]
    @property
    def is_closed(self) -> bool:
        """False while the candle's time window is still running (values may still change)."""
        end = self.timestamp + timedelta(seconds=self.timeframe.seconds)
        return end <= datetime.now(timezone.utc)


class Asset(BaseModel):
    """A tradable pair offered by the data provider."""

    symbol: str
    base: str
    quote: str
    group: Optional[str] = None
    source: str


class CandlesResponse(BaseModel):
    asset: str
    timeframe: Timeframe
    source: Optional[str] = None
    count: int
    stale: bool = False
    warnings: list[str] = Field(default_factory=list)
    candles: list[Candle]


class AssetsResponse(BaseModel):
    source: str
    count: int
    stale: bool = False
    updated_at: Optional[datetime] = None
    assets: list[Asset]
