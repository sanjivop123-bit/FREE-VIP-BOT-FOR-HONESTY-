"""Market data collection: providers, validation and orchestration."""
