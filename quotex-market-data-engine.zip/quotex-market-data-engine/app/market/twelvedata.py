"""Twelve Data implementation of MarketDataProvider (https://twelvedata.com).

Endpoints used:
  GET /forex_pairs   - list of currency pairs
  GET /time_series   - OHLC candles (interval 1min / 5min / 15min)

The API key is sent in the ``Authorization: apikey <key>`` header, never in the URL, so it cannot
leak into logs through request URLs.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable, Optional

import httpx

from app.market.models import Asset, RawCandle, Timeframe
from app.market.provider import (
    MarketDataError,
    MarketDataProvider,
    ProviderAuthError,
    ProviderConfigError,
    ProviderDataError,
    ProviderRateLimitError,
    ProviderRequestError,
    ProviderUnavailableError,
    UnknownAssetError,
    UnsupportedTimeframeError,
)
from app.market.validator import normalize_asset

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://api.twelvedata.com"
MAX_RETRY_DELAY_SECONDS = 30.0
MAX_OUTPUTSIZE = 5000


class TwelveDataProvider(MarketDataProvider):
    name = "twelvedata"

    _INTERVALS = {
        Timeframe.M1: "1min",
        Timeframe.M5: "5min",
        Timeframe.M15: "15min",
    }
    supported_timeframes = frozenset(_INTERVALS)

    def __init__(
        self,
        api_key: Optional[str],
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 10.0,
        max_retries: int = 3,
        backoff_seconds: float = 1.0,
        client: Optional[httpx.AsyncClient] = None,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self._api_key = (api_key or "").strip() or None
        self._base_url = base_url.rstrip("/")
        self._max_retries = max(0, max_retries)
        self._backoff = max(0.0, backoff_seconds)
        self._sleep = sleep
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient(timeout=httpx.Timeout(timeout))

    # ------------------------------------------------------------------ interface

    @property
    def is_configured(self) -> bool:
        return self._api_key is not None

    async def list_assets(self) -> list[Asset]:
        payload = await self._request_json("/forex_pairs", {})
        data = payload.get("data")
        if not isinstance(data, list):
            raise ProviderDataError("Unexpected /forex_pairs response: no 'data' list")

        assets: dict[str, Asset] = {}
        for item in data:
            if not isinstance(item, dict):
                continue
            try:
                symbol = normalize_asset(item.get("symbol"))
            except ValueError:
                logger.debug("Skipping unusable forex pair entry: %r", item.get("symbol"))
                continue
            base, quote = symbol.split("/")
            group = item.get("currency_group")
            assets[symbol] = Asset(
                symbol=symbol,
                base=base,
                quote=quote,
                group=group if isinstance(group, str) else None,
                source=self.name,
            )
        if not assets:
            raise ProviderDataError("Provider returned no usable currency pairs")
        return sorted(assets.values(), key=lambda asset: asset.symbol)

    async def fetch_candles(
        self, asset: str, timeframe: Timeframe, limit: int
    ) -> list[RawCandle]:
        interval = self._INTERVALS.get(timeframe)
        if interval is None:
            raise UnsupportedTimeframeError(
                f"{self.name} does not support timeframe {timeframe.value}"
            )
        params = {
            "symbol": asset,
            "interval": interval,
            "outputsize": max(1, min(int(limit), MAX_OUTPUTSIZE)),
            "timezone": "UTC",
        }
        payload = await self._request_json("/time_series", params)
        values = payload.get("values")
        if not isinstance(values, list):
            raise ProviderDataError("Unexpected /time_series response: no 'values' list")

        candles: list[RawCandle] = []
        for item in values:
            if not isinstance(item, dict):
                candles.append(RawCandle(None, None, None, None, None))  # rejected by validator
                continue
            candles.append(
                RawCandle(
                    timestamp=item.get("datetime"),
                    open=item.get("open"),
                    high=item.get("high"),
                    low=item.get("low"),
                    close=item.get("close"),
                    volume=item.get("volume"),
                )
            )
        return candles

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    # ------------------------------------------------------------------ HTTP plumbing

    async def _request_json(self, path: str, params: dict[str, Any]) -> dict[str, Any]:
        if self._api_key is None:
            raise ProviderConfigError(
                "TWELVEDATA_API_KEY is not set. Create a free key at https://twelvedata.com "
                "and put it in your .env file."
            )
        headers = {"Authorization": f"apikey {self._api_key}", "Accept": "application/json"}
        attempt = 0
        while True:
            try:
                return await self._request_once(path, params, headers)
            except (ProviderRateLimitError, ProviderUnavailableError) as exc:
                if attempt >= self._max_retries:
                    raise
                if exc.retry_after is not None and exc.retry_after > MAX_RETRY_DELAY_SECONDS:
                    raise  # waiting that long inside a request is pointless
                delay = (
                    exc.retry_after
                    if exc.retry_after is not None
                    else self._backoff * (2**attempt)
                )
                attempt += 1
                logger.warning(
                    "%s on %s (%s); retry %d/%d in %.1fs",
                    exc.code,
                    path,
                    exc.message,
                    attempt,
                    self._max_retries,
                    delay,
                )
                await self._sleep(delay)

    async def _request_once(
        self, path: str, params: dict[str, Any], headers: dict[str, str]
    ) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        try:
            response = await self._client.get(url, params=params, headers=headers)
        except httpx.TimeoutException as exc:
            raise ProviderUnavailableError(f"Timed out calling {path}") from exc
        except httpx.HTTPError as exc:
            raise ProviderUnavailableError(
                f"Network error calling {path}: {type(exc).__name__}"
            ) from exc

        try:
            payload: Any = response.json()
        except ValueError:
            payload = None

        status = response.status_code
        if isinstance(payload, dict) and payload.get("status") == "error":
            code = payload.get("code")
            message = str(payload.get("message") or "unknown error")[:200]
            raise self._map_error(code if isinstance(code, int) else status, message, response)
        if status >= 400:
            raise self._map_error(status, f"HTTP {status}", response)
        if not isinstance(payload, dict):
            raise ProviderDataError(f"{path} did not return a JSON object")
        return payload

    @staticmethod
    def _retry_after(response: Any) -> Optional[float]:
        raw = response.headers.get("retry-after")
        if raw is None:
            return None
        try:
            value = float(raw)
        except ValueError:
            return None
        return value if value >= 0 else None

    def _map_error(self, code: int, message: str, response: Any) -> MarketDataError:
        if code in (401, 403):
            return ProviderAuthError(
                f"Twelve Data rejected the request ({code}): {message}. "
                "Check TWELVEDATA_API_KEY and that your plan includes this data."
            )
        if code == 429:
            return ProviderRateLimitError(
                f"Twelve Data rate limit reached: {message}",
                retry_after=self._retry_after(response),
            )
        if code >= 500:
            return ProviderUnavailableError(f"Twelve Data server error ({code}): {message}")
        if code in (400, 404) and "symbol" in message.lower():
            return UnknownAssetError(f"Twelve Data does not recognise the symbol: {message}")
        return ProviderRequestError(f"Twelve Data rejected the request ({code}): {message}")
