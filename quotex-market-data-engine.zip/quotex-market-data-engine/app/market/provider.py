"""Provider interface for market-data sources, plus the typed errors the engine raises.

To add a new data source: subclass ``MarketDataProvider``, then register it in ``build_provider``.
Nothing else in the project needs to change.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

from app.market.models import Asset, RawCandle, Timeframe

if TYPE_CHECKING:  # pragma: no cover
    from app.config import Settings


class MarketDataError(Exception):
    """Base class for every expected failure. Carries the HTTP status the API should use."""

    status_code: int = 500
    code: str = "market_data_error"

    def __init__(self, message: str, *, retry_after: Optional[float] = None) -> None:
        super().__init__(message)
        self.message = message
        self.retry_after = retry_after


class InvalidAssetError(MarketDataError):
    status_code = 400
    code = "invalid_asset"


class UnsupportedTimeframeError(MarketDataError):
    status_code = 400
    code = "unsupported_timeframe"


class UnknownAssetError(MarketDataError):
    status_code = 404
    code = "unknown_asset"


class ProviderError(MarketDataError):
    """The data provider could not deliver usable data."""

    status_code = 502
    code = "provider_error"


class ProviderConfigError(ProviderError):
    """Provider is not configured (for example, the API key is missing)."""

    status_code = 503
    code = "provider_not_configured"


class ProviderAuthError(ProviderError):
    """The provider rejected our API key or our plan does not include the resource."""

    status_code = 502
    code = "provider_auth_failed"


class ProviderRateLimitError(ProviderError):
    """The provider's request limit was hit."""

    status_code = 429
    code = "provider_rate_limited"


class ProviderUnavailableError(ProviderError):
    """Network failure, timeout or a 5xx from the provider."""

    status_code = 503
    code = "provider_unavailable"


class ProviderRequestError(ProviderError):
    """The provider rejected the request parameters."""

    status_code = 502
    code = "provider_request_rejected"


class ProviderDataError(ProviderError):
    """The provider answered, but the payload was malformed or entirely invalid."""

    status_code = 502
    code = "provider_bad_data"


class MarketDataProvider(ABC):
    """Contract every data source must implement."""

    #: Short identifier stored with every candle as its data source.
    name: str = "unknown"
    #: Timeframes this provider can serve.
    supported_timeframes: frozenset[Timeframe] = frozenset(Timeframe)

    @property
    @abstractmethod
    def is_configured(self) -> bool:
        """True when credentials needed to reach the provider are present."""

    @abstractmethod
    async def list_assets(self) -> list[Asset]:
        """Return every currency pair the provider offers."""

    @abstractmethod
    async def fetch_candles(
        self, asset: str, timeframe: Timeframe, limit: int
    ) -> list[RawCandle]:
        """Return up to ``limit`` of the most recent candles, unvalidated, in any order."""

    async def check_connection(self) -> None:
        """Raise a ProviderError if the provider cannot currently be used."""
        await self.fetch_candles("EUR/USD", Timeframe.M1, 1)

    async def aclose(self) -> None:
        """Release network resources."""
        return None


def build_provider(settings: "Settings") -> MarketDataProvider:
    """Create the provider selected by the PROVIDER setting."""
    name = settings.provider.lower()
    if name == "twelvedata":
        from app.market.twelvedata import TwelveDataProvider

        return TwelveDataProvider(
            api_key=settings.twelvedata_api_key,
            base_url=settings.twelvedata_base_url,
            timeout=settings.request_timeout_seconds,
            max_retries=settings.max_retries,
            backoff_seconds=settings.retry_backoff_seconds,
        )
    raise ProviderConfigError(f"Unknown PROVIDER {settings.provider!r}. Available: twelvedata")
