"""Quotex Market Data Engine."""
