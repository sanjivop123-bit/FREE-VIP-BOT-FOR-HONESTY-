"""FastAPI application: REST API for the Quotex Market Data Engine.

Run with:  uvicorn app.main:app --host 0.0.0.0 --port 8000
"""
import asyncio
import logging
import math
from contextlib import asynccontextmanager, suppress
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import JSONResponse

from app.config import APP_NAME, APP_VERSION, Settings, configure_logging, get_settings
from app.database.storage import SQLiteStorage, StorageError
from app.market.collector import MarketCollector
from app.market.models import AssetsResponse, CandlesResponse, Timeframe
from app.market.provider import MarketDataError, MarketDataProvider, build_provider

logger = logging.getLogger("app.main")


def create_app(
    settings: Optional[Settings] = None,
    provider: Optional[MarketDataProvider] = None,
) -> FastAPI:
    """Application factory. ``settings`` and ``provider`` can be injected (used by the tests)."""
    settings = settings or get_settings()
    configure_logging(settings.log_level)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        storage = SQLiteStorage(settings.database_path)
        storage.initialize()
        active_provider = provider or build_provider(settings)
        collector = MarketCollector(active_provider, storage, settings)

        app.state.settings = settings
        app.state.storage = storage
        app.state.provider = active_provider
        app.state.collector = collector
        app.state.collector_task = None

        logger.info(
            "Starting %s v%s (provider=%s, configured=%s, database=%s)",
            APP_NAME,
            APP_VERSION,
            active_provider.name,
            active_provider.is_configured,
            settings.database_path,
        )
        if not active_provider.is_configured:
            logger.warning(
                "Provider %s has no API key configured; data endpoints will return 503 until "
                "it is set (see README).",
                active_provider.name,
            )
        if settings.collector_enabled:
            app.state.collector_task = asyncio.create_task(
                collector.run_forever(), name="market-collector"
            )
        try:
            yield
        finally:
            task = app.state.collector_task
            if task is not None:
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task
            await active_provider.aclose()
            logger.info("Shutdown complete")

    app = FastAPI(
        title=APP_NAME,
        version=APP_VERSION,
        description="Market data collection (OHLC candles) for forex pairs. No trading functionality.",
        lifespan=lifespan,
    )

    # ------------------------------------------------------------------ error handling

    @app.exception_handler(MarketDataError)
    async def market_data_error_handler(request: Request, exc: MarketDataError) -> JSONResponse:
        headers = {}
        if exc.retry_after is not None:
            headers["Retry-After"] = str(max(1, math.ceil(exc.retry_after)))
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": {"code": exc.code, "message": exc.message}},
            headers=headers,
        )

    @app.exception_handler(StorageError)
    async def storage_error_handler(request: Request, exc: StorageError) -> JSONResponse:
        logger.error("Storage error: %s", exc)
        return JSONResponse(
            status_code=500,
            content={"error": {"code": "storage_error", "message": "Database error"}},
        )

    # ------------------------------------------------------------------ endpoints

    @app.get("/", tags=["meta"])
    async def root(request: Request) -> dict:
        active_provider: MarketDataProvider = request.app.state.provider
        return {
            "name": APP_NAME,
            "version": APP_VERSION,
            "provider": active_provider.name,
            "docs": "/docs",
            "endpoints": ["/health", "/health/provider", "/assets", "/market/candles"],
        }

    @app.get("/health", tags=["health"])
    async def health(request: Request) -> JSONResponse:
        """Liveness/readiness: checks the database and whether the provider is configured.

        Does not call the provider (no API credits used). Use /health/provider for that.
        """
        storage: SQLiteStorage = request.app.state.storage
        active_provider: MarketDataProvider = request.app.state.provider
        task = request.app.state.collector_task

        database_ok = True
        try:
            await asyncio.to_thread(storage.ping)
        except StorageError as exc:
            database_ok = False
            logger.error("Health check: database failure: %s", exc)

        configured = active_provider.is_configured
        body = {
            "status": "ok" if database_ok and configured else "degraded",
            "version": APP_VERSION,
            "time": datetime.now(timezone.utc).isoformat(),
            "database": "ok" if database_ok else "error",
            "provider": {"name": active_provider.name, "configured": configured},
            "collector": {
                "enabled": request.app.state.settings.collector_enabled,
                "running": task is not None and not task.done(),
            },
        }
        return JSONResponse(status_code=200 if database_ok else 503, content=body)

    @app.get("/health/provider", tags=["health"])
    async def health_provider(request: Request) -> JSONResponse:
        """Makes one real request to the data provider (uses one API credit)."""
        active_provider: MarketDataProvider = request.app.state.provider
        checked_at = datetime.now(timezone.utc).isoformat()
        try:
            await active_provider.check_connection()
        except MarketDataError as exc:
            return JSONResponse(
                status_code=503,
                content={
                    "status": "error",
                    "provider": active_provider.name,
                    "error": exc.code,
                    "message": exc.message,
                    "checked_at": checked_at,
                },
            )
        return JSONResponse(
            content={"status": "ok", "provider": active_provider.name, "checked_at": checked_at}
        )

    @app.get("/assets", response_model=AssetsResponse, tags=["market"])
    async def list_assets(
        request: Request,
        search: Optional[str] = Query(
            None, max_length=20, description="Filter by text in the symbol, e.g. 'USD'"
        ),
        refresh: bool = Query(False, description="Force a refresh from the provider"),
    ) -> AssetsResponse:
        """All currency pairs offered by the data provider."""
        collector: MarketCollector = request.app.state.collector
        result = await collector.get_assets(force_refresh=refresh)
        assets = result.assets
        if search:
            needle = search.strip().upper()
            assets = [a for a in assets if needle in a.symbol]
        return AssetsResponse(
            source=request.app.state.provider.name,
            count=len(assets),
            stale=result.stale,
            updated_at=result.updated_at,
            assets=assets,
        )

    @app.get("/market/candles", response_model=CandlesResponse, tags=["market"])
    async def get_candles(
        request: Request,
        asset: str = Query(..., min_length=3, max_length=20, description="e.g. EUR/USD"),
        timeframe: Timeframe = Query(Timeframe.M1, description="1m, 5m or 15m"),
        limit: Optional[int] = Query(None, ge=1, description="Number of candles (default from settings)"),
        refresh: bool = Query(True, description="Fetch fresh data from the provider first"),
        closed_only: bool = Query(False, description="Exclude the still-forming candle"),
    ) -> CandlesResponse:
        """OHLC candles, oldest first. Timestamps are candle OPEN times in UTC."""
        active_settings: Settings = request.app.state.settings
        collector: MarketCollector = request.app.state.collector

        effective_limit = limit if limit is not None else active_settings.default_candle_limit
        if effective_limit > active_settings.max_candle_limit:
            raise HTTPException(
                status_code=422,
                detail=f"limit must be <= {active_settings.max_candle_limit}",
            )

        result = await collector.get_candles(
            asset,
            timeframe,
            effective_limit,
            refresh=refresh,
            closed_only=closed_only,
        )
        return CandlesResponse(
            asset=result.asset,
            timeframe=result.timeframe,
            source=result.source,
            count=len(result.candles),
            stale=result.stale,
            warnings=result.warnings,
            candles=result.candles,
        )

    return app


app = create_app()
