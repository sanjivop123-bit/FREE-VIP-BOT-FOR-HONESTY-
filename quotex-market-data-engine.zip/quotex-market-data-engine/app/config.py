"""Application settings, read from environment variables (and an optional .env file)."""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from functools import lru_cache
from typing import Mapping, Optional

from dotenv import load_dotenv

from app.market.models import Timeframe
from app.market.validator import normalize_asset

APP_NAME = "Quotex Market Data Engine"
APP_VERSION = "0.1.0"

_LOG_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}


class ConfigError(ValueError):
    """An environment variable has an invalid value."""


def _get_str(env: Mapping[str, str], key: str, default: Optional[str] = None) -> Optional[str]:
    value = env.get(key)
    if value is None:
        return default
    value = value.strip()
    return value or default


def _get_int(
    env: Mapping[str, str], key: str, default: int, minimum: int = 0, maximum: Optional[int] = None
) -> int:
    raw = _get_str(env, key)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError:
        raise ConfigError(f"{key} must be an integer, got {raw!r}") from None
    if value < minimum or (maximum is not None and value > maximum):
        bounds = f">= {minimum}" if maximum is None else f"between {minimum} and {maximum}"
        raise ConfigError(f"{key} must be {bounds}, got {value}")
    return value


def _get_float(env: Mapping[str, str], key: str, default: float, minimum: float = 0.0) -> float:
    raw = _get_str(env, key)
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError:
        raise ConfigError(f"{key} must be a number, got {raw!r}") from None
    if value < minimum:
        raise ConfigError(f"{key} must be >= {minimum}, got {value}")
    return value


def _get_bool(env: Mapping[str, str], key: str, default: bool) -> bool:
    raw = _get_str(env, key)
    if raw is None:
        return default
    lowered = raw.lower()
    if lowered in {"1", "true", "yes", "on"}:
        return True
    if lowered in {"0", "false", "no", "off"}:
        return False
    raise ConfigError(f"{key} must be true or false, got {raw!r}")


def _get_assets(env: Mapping[str, str], key: str) -> tuple[str, ...]:
    raw = _get_str(env, key)
    if raw is None:
        return ()
    if raw.strip().upper() == "ALL":
        return ("ALL",)
    symbols: list[str] = []
    for token in raw.split(","):
        token = token.strip()
        if not token:
            continue
        try:
            symbol = normalize_asset(token)
        except ValueError as exc:
            raise ConfigError(f"{key}: {exc}") from None
        if symbol not in symbols:
            symbols.append(symbol)
    return tuple(symbols)


def _get_timeframes(
    env: Mapping[str, str], key: str, default: tuple[Timeframe, ...]
) -> tuple[Timeframe, ...]:
    raw = _get_str(env, key)
    if raw is None:
        return default
    result: list[Timeframe] = []
    for token in raw.split(","):
        token = token.strip().lower()
        if not token:
            continue
        try:
            timeframe = Timeframe(token)
        except ValueError:
            allowed = ", ".join(t.value for t in Timeframe)
            raise ConfigError(f"{key}: unknown timeframe {token!r} (allowed: {allowed})") from None
        if timeframe not in result:
            result.append(timeframe)
    if not result:
        raise ConfigError(f"{key} must list at least one timeframe")
    return tuple(result)


@dataclass(frozen=True)
class Settings:
    provider: str = "twelvedata"
    twelvedata_api_key: Optional[str] = None
    twelvedata_base_url: str = "https://api.twelvedata.com"
    database_path: str = "data/market.db"
    request_timeout_seconds: float = 10.0
    max_retries: int = 3
    retry_backoff_seconds: float = 1.0
    assets_cache_ttl_seconds: int = 3600
    candles_cache_ttl_seconds: int = 10
    default_candle_limit: int = 100
    max_candle_limit: int = 1000
    collector_enabled: bool = False
    collector_assets: tuple[str, ...] = ()
    collector_timeframes: tuple[Timeframe, ...] = (Timeframe.M1, Timeframe.M5, Timeframe.M15)
    collector_cycle_seconds: float = 60.0
    collector_request_delay_seconds: float = 8.0
    collector_outputsize: int = 100
    log_level: str = "INFO"

    @classmethod
    def from_env(cls, env: Optional[Mapping[str, str]] = None) -> "Settings":
        env = os.environ if env is None else env
        d = cls()

        default_limit = _get_int(env, "DEFAULT_CANDLE_LIMIT", d.default_candle_limit, 1, 5000)
        max_limit = _get_int(env, "MAX_CANDLE_LIMIT", d.max_candle_limit, 1, 5000)
        if default_limit > max_limit:
            raise ConfigError("DEFAULT_CANDLE_LIMIT must not exceed MAX_CANDLE_LIMIT")

        log_level = (_get_str(env, "LOG_LEVEL", d.log_level) or d.log_level).upper()
        if log_level not in _LOG_LEVELS:
            raise ConfigError(f"LOG_LEVEL must be one of {sorted(_LOG_LEVELS)}, got {log_level!r}")

        return cls(
            provider=(_get_str(env, "PROVIDER", d.provider) or d.provider).lower(),
            twelvedata_api_key=_get_str(env, "TWELVEDATA_API_KEY"),
            twelvedata_base_url=_get_str(env, "TWELVEDATA_BASE_URL", d.twelvedata_base_url)
            or d.twelvedata_base_url,
            database_path=_get_str(env, "DATABASE_PATH", d.database_path) or d.database_path,
            request_timeout_seconds=_get_float(
                env, "REQUEST_TIMEOUT_SECONDS", d.request_timeout_seconds, 0.1
            ),
            max_retries=_get_int(env, "MAX_RETRIES", d.max_retries, 0, 10),
            retry_backoff_seconds=_get_float(
                env, "RETRY_BACKOFF_SECONDS", d.retry_backoff_seconds, 0.0
            ),
            assets_cache_ttl_seconds=_get_int(
                env, "ASSETS_CACHE_TTL_SECONDS", d.assets_cache_ttl_seconds, 0
            ),
            candles_cache_ttl_seconds=_get_int(
                env, "CANDLES_CACHE_TTL_SECONDS", d.candles_cache_ttl_seconds, 0
            ),
            default_candle_limit=default_limit,
            max_candle_limit=max_limit,
            collector_enabled=_get_bool(env, "COLLECTOR_ENABLED", d.collector_enabled),
            collector_assets=_get_assets(env, "COLLECTOR_ASSETS"),
            collector_timeframes=_get_timeframes(
                env, "COLLECTOR_TIMEFRAMES", d.collector_timeframes
            ),
            collector_cycle_seconds=_get_float(
                env, "COLLECTOR_CYCLE_SECONDS", d.collector_cycle_seconds, 1.0
            ),
            collector_request_delay_seconds=_get_float(
                env, "COLLECTOR_REQUEST_DELAY_SECONDS", d.collector_request_delay_seconds, 0.0
            ),
            collector_outputsize=_get_int(
                env, "COLLECTOR_OUTPUTSIZE", d.collector_outputsize, 1, 5000
            ),
            log_level=log_level,
        )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Load settings once from the environment, after reading a local .env file if present."""
    load_dotenv()
    return Settings.from_env()


def configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )
    # httpx logs every request at INFO; keep the noise (and any URL details) out of the logs.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
