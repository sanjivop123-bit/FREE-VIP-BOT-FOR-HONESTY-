import asyncio
from datetime import datetime, timedelta, timezone

import pytest

from app.config import Settings
from app.database.storage import SQLiteStorage
from app.market.collector import MarketCollector
from app.market.models import RawCandle, Timeframe
from app.market.provider import (
    InvalidAssetError,
    ProviderDataError,
    ProviderRateLimitError,
    ProviderUnavailableError,
    UnknownAssetError,
    UnsupportedTimeframeError,
)
from tests.fakes import FakeProvider, make_raw_candles, utcnow


def run(coro):
    return asyncio.run(coro)


def build(tmp_path, provider=None, clock=None, **overrides):
    settings = Settings(
        database_path=str(tmp_path / "t.db"), collector_request_delay_seconds=0.0, **overrides
    )
    storage = SQLiteStorage(settings.database_path)
    storage.initialize()
    provider = provider or FakeProvider()
    kwargs = {"clock": clock} if clock else {}
    return MarketCollector(provider, storage, settings, **kwargs), storage, provider


# ---------------------------------------------------------------- collect


def test_collect_validates_and_stores(tmp_path):
    collector, storage, _ = build(tmp_path)
    result = run(collector.collect("eurusd", Timeframe.M1, 5))
    assert (result.received, result.accepted, result.rejected, result.stored) == (5, 5, 0, 5)
    assert storage.count_candles("EUR/USD", Timeframe.M1) == 5
    assert storage.get_candles("EUR/USD", Timeframe.M1, 1)[0].source == "fake"


def test_collect_drops_bad_rows_but_keeps_good_ones(tmp_path):
    provider = FakeProvider()
    provider.rows = make_raw_candles(Timeframe.M1, 3) + [RawCandle("nope", "x", "x", "x", "x")]
    collector, storage, _ = build(tmp_path, provider)
    result = run(collector.collect("EUR/USD", Timeframe.M1, 10))
    assert (result.accepted, result.rejected) == (3, 1)
    assert storage.count_candles() == 3


def test_collect_raises_when_every_row_is_invalid(tmp_path):
    provider = FakeProvider()
    provider.rows = [RawCandle("nope", "x", "x", "x", "x")]
    collector, storage, _ = build(tmp_path, provider)
    with pytest.raises(ProviderDataError):
        run(collector.collect("EUR/USD", Timeframe.M1, 10))
    assert storage.count_candles() == 0


# ---------------------------------------------------------------- get_candles


def test_get_candles_fetches_then_respects_cache_ttl(tmp_path):
    collector, _, provider = build(tmp_path)
    first = run(collector.get_candles("EUR/USD", Timeframe.M1, 5))
    assert len(first.candles) == 5 and not first.stale and first.source == "fake"
    assert first.candles == sorted(first.candles, key=lambda c: c.timestamp)
    run(collector.get_candles("EUR/USD", Timeframe.M1, 5))  # within TTL
    assert provider.candle_calls == 1
    run(collector.get_candles("EUR/USD", Timeframe.M1, 5, refresh=False))
    assert provider.candle_calls == 1


def test_refresh_false_on_empty_database_warns(tmp_path):
    collector, _, provider = build(tmp_path)
    result = run(collector.get_candles("EUR/USD", Timeframe.M1, 5, refresh=False))
    assert result.candles == [] and result.warnings
    assert provider.candle_calls == 0


def test_closed_only_hides_forming_candle(tmp_path):
    collector, _, _ = build(tmp_path)
    all_rows = run(collector.get_candles("EUR/USD", Timeframe.M1, 5))
    closed = run(collector.get_candles("EUR/USD", Timeframe.M1, 5, refresh=False, closed_only=True))
    assert len(all_rows.candles) == 5
    assert len(closed.candles) == 4
    assert all(c.is_closed for c in closed.candles)


def test_closed_only_on_cold_database_still_returns_full_limit(tmp_path):
    collector, _, _ = build(tmp_path)
    result = run(collector.get_candles("EUR/USD", Timeframe.M1, 5, closed_only=True))
    assert len(result.candles) == 5
    assert all(c.is_closed for c in result.candles)


def test_provider_failure_returns_stale_stored_candles(tmp_path):
    collector, _, provider = build(tmp_path, candles_cache_ttl_seconds=0)
    run(collector.get_candles("EUR/USD", Timeframe.M1, 5))
    provider.candles_error = ProviderUnavailableError("down")
    result = run(collector.get_candles("EUR/USD", Timeframe.M1, 5))
    assert result.stale is True
    assert len(result.candles) == 5
    assert "provider_unavailable" in result.warnings[0]


def test_provider_failure_without_stored_data_raises(tmp_path):
    provider = FakeProvider()
    provider.candles_error = ProviderRateLimitError("slow down", retry_after=7)
    collector, _, _ = build(tmp_path, provider)
    with pytest.raises(ProviderRateLimitError) as info:
        run(collector.get_candles("EUR/USD", Timeframe.M1, 5))
    assert info.value.retry_after == 7


def test_unknown_asset_never_reaches_provider(tmp_path):
    collector, _, provider = build(tmp_path)
    with pytest.raises(UnknownAssetError):
        run(collector.get_candles("XXX/YYY", Timeframe.M1, 5))
    assert provider.candle_calls == 0


def test_invalid_asset_symbol(tmp_path):
    collector, _, _ = build(tmp_path)
    with pytest.raises(InvalidAssetError):
        run(collector.get_candles("EUR/USD (OTC)", Timeframe.M1, 5))


def test_unsupported_timeframe(tmp_path):
    provider = FakeProvider()
    provider.supported_timeframes = frozenset({Timeframe.M1})
    collector, _, _ = build(tmp_path, provider)
    with pytest.raises(UnsupportedTimeframeError):
        run(collector.get_candles("EUR/USD", Timeframe.M5, 5))


def test_candles_still_served_when_asset_list_is_unavailable(tmp_path):
    provider = FakeProvider()
    provider.assets_error = ProviderUnavailableError("assets down")
    collector, _, _ = build(tmp_path, provider)
    result = run(collector.get_candles("EUR/USD", Timeframe.M1, 3))
    assert len(result.candles) == 3


# ---------------------------------------------------------------- assets


def test_assets_are_cached(tmp_path):
    collector, _, provider = build(tmp_path)
    first = run(collector.get_assets())
    run(collector.get_assets())
    assert provider.asset_calls == 1
    assert [a.symbol for a in first.assets] == ["EUR/USD", "GBP/USD", "USD/JPY"]
    run(collector.get_assets(force_refresh=True))
    assert provider.asset_calls == 2


def test_assets_fall_back_to_stored_list_when_provider_fails(tmp_path):
    collector, _, provider = build(tmp_path, assets_cache_ttl_seconds=0)
    run(collector.get_assets())
    provider.assets_error = ProviderUnavailableError("down")
    result = run(collector.get_assets())
    assert result.stale is True and len(result.assets) == 3


def test_assets_error_without_stored_list_raises(tmp_path):
    provider = FakeProvider()
    provider.assets_error = ProviderUnavailableError("down")
    collector, _, _ = build(tmp_path, provider)
    with pytest.raises(ProviderUnavailableError):
        run(collector.get_assets())


# ---------------------------------------------------------------- background polling


class Clock:
    def __init__(self, now):
        self.now = now

    def __call__(self):
        return self.now


def test_run_cycle_polls_each_series_once_per_period(tmp_path):
    clock = Clock(datetime(2026, 11, 15, 12, 0, 30, tzinfo=timezone.utc))
    provider = FakeProvider(clock=clock)
    collector, storage, _ = build(
        tmp_path,
        provider,
        clock=clock,
        collector_assets=("EUR/USD", "GBP/USD"),
        collector_timeframes=(Timeframe.M1, Timeframe.M5),
    )
    state = {}
    assert run(collector.run_cycle(state)) == 4
    assert run(collector.run_cycle(state)) == 0  # same minute: nothing due
    assert provider.candle_calls == 4

    clock.now += timedelta(seconds=40)  # 12:01:10 -> new 1m period, same 5m period
    assert run(collector.run_cycle(state)) == 2
    assert provider.candle_calls == 6
    assert storage.count_candles("EUR/USD", Timeframe.M1) > 0


def test_run_cycle_survives_failures_and_retries_them(tmp_path):
    clock = Clock(datetime(2026, 11, 15, 12, 0, 30, tzinfo=timezone.utc))
    provider = FakeProvider(clock=clock)
    provider.candles_error = ProviderUnavailableError("down")
    collector, _, _ = build(
        tmp_path,
        provider,
        clock=clock,
        collector_assets=("EUR/USD",),
        collector_timeframes=(Timeframe.M1,),
    )
    state = {}
    assert run(collector.run_cycle(state)) == 0
    provider.candles_error = None
    assert run(collector.run_cycle(state)) == 1  # failed series is retried within the same period


def test_run_cycle_all_assets_keyword(tmp_path):
    clock = Clock(utcnow())
    provider = FakeProvider(clock=clock)
    collector, _, _ = build(
        tmp_path,
        provider,
        clock=clock,
        collector_assets=("ALL",),
        collector_timeframes=(Timeframe.M15,),
    )
    assert run(collector.run_cycle({})) == 3
