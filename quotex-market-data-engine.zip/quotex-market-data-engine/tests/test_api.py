"""API tests: the FastAPI app is wired to a fake provider and a temporary SQLite file."""
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")

from fastapi.testclient import TestClient  # noqa: E402

from app.config import Settings  # noqa: E402
from app.main import create_app  # noqa: E402
from app.market.provider import (  # noqa: E402
    ProviderAuthError,
    ProviderRateLimitError,
    ProviderUnavailableError,
)
from tests.fakes import FakeProvider  # noqa: E402


@pytest.fixture
def provider():
    return FakeProvider()


@pytest.fixture
def client(tmp_path, provider):
    settings = Settings(database_path=str(tmp_path / "api.db"), max_candle_limit=50, default_candle_limit=10)
    with TestClient(create_app(settings=settings, provider=provider)) as c:
        yield c


def test_root(client):
    body = client.get("/").json()
    assert body["name"] == "Quotex Market Data Engine"
    assert body["provider"] == "fake"
    assert "/market/candles" in body["endpoints"]


def test_health_ok(client):
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["database"] == "ok"
    assert body["provider"] == {"name": "fake", "configured": True}
    assert body["collector"]["running"] is False


def test_health_is_degraded_but_alive_without_api_key(tmp_path):
    settings = Settings(database_path=str(tmp_path / "x.db"))
    with TestClient(create_app(settings=settings, provider=FakeProvider(configured=False))) as c:
        response = c.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "degraded"


def test_health_provider_ok_and_failing(client, provider):
    assert client.get("/health/provider").json()["status"] == "ok"
    provider.candles_error = ProviderAuthError("bad key")
    response = client.get("/health/provider")
    assert response.status_code == 503
    assert response.json()["error"] == "provider_auth_failed"


def test_assets_listing_and_search(client):
    body = client.get("/assets").json()
    assert body["count"] == 3 and body["stale"] is False and body["source"] == "fake"
    assert {a["symbol"] for a in body["assets"]} == {"EUR/USD", "GBP/USD", "USD/JPY"}
    filtered = client.get("/assets", params={"search": "jpy"}).json()
    assert [a["symbol"] for a in filtered["assets"]] == ["USD/JPY"]


def test_assets_unavailable_returns_503(tmp_path):
    provider = FakeProvider()
    provider.assets_error = ProviderUnavailableError("down")
    settings = Settings(database_path=str(tmp_path / "x.db"))
    with TestClient(create_app(settings=settings, provider=provider)) as c:
        response = c.get("/assets")
    assert response.status_code == 503
    assert response.json()["error"]["code"] == "provider_unavailable"


def test_candles_default_response_shape(client):
    response = client.get("/market/candles", params={"asset": "EUR/USD", "timeframe": "1m"})
    assert response.status_code == 200
    body = response.json()
    assert body["asset"] == "EUR/USD" and body["timeframe"] == "1m"
    assert body["count"] == 10 and body["stale"] is False and body["source"] == "fake"
    first = body["candles"][0]
    for key in ("timestamp", "open", "high", "low", "close", "source", "fetched_at", "is_closed"):
        assert key in first
    stamps = [c["timestamp"] for c in body["candles"]]
    assert stamps == sorted(stamps)


def test_candles_normalizes_asset_and_accepts_other_timeframes(client):
    for tf in ("5m", "15m"):
        response = client.get("/market/candles", params={"asset": "eurusd", "timeframe": tf, "limit": 3})
        assert response.status_code == 200
        assert response.json()["asset"] == "EUR/USD" and response.json()["count"] == 3


def test_closed_only(client):
    body = client.get("/market/candles", params={"asset": "EUR/USD", "limit": 5, "closed_only": "true"}).json()
    assert body["count"] == 5  # one extra candle is fetched to make up for the forming one
    assert all(c["is_closed"] for c in body["candles"])
    full = client.get("/market/candles", params={"asset": "EUR/USD", "limit": 5, "refresh": "false"}).json()
    assert full["candles"][-1]["is_closed"] is False


def test_candle_validation_errors(client):
    assert client.get("/market/candles", params={"asset": "EUR/USD", "timeframe": "1h"}).status_code == 422
    assert client.get("/market/candles", params={"asset": "EUR/USD", "limit": 0}).status_code == 422
    assert client.get("/market/candles", params={"asset": "EUR/USD", "limit": 51}).status_code == 422
    assert client.get("/market/candles").status_code == 422
    bad_symbol = client.get("/market/candles", params={"asset": "EUR/USD (OTC)"})
    assert bad_symbol.status_code == 400
    assert bad_symbol.json()["error"]["code"] == "invalid_asset"


def test_unknown_asset_is_404(client):
    response = client.get("/market/candles", params={"asset": "XXX/YYY"})
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "unknown_asset"


def test_rate_limited_without_cache_returns_429_with_retry_after(client, provider):
    provider.candles_error = ProviderRateLimitError("limit", retry_after=12)
    response = client.get("/market/candles", params={"asset": "EUR/USD"})
    assert response.status_code == 429
    assert response.headers["retry-after"] == "12"
    assert response.json()["error"]["code"] == "provider_rate_limited"


def test_provider_down_with_cache_returns_stale_data(tmp_path, provider):
    settings = Settings(database_path=str(tmp_path / "s.db"), candles_cache_ttl_seconds=0)
    with TestClient(create_app(settings=settings, provider=provider)) as c:
        assert c.get("/market/candles", params={"asset": "EUR/USD", "limit": 4}).status_code == 200
        provider.candles_error = ProviderUnavailableError("down")
        response = c.get("/market/candles", params={"asset": "EUR/USD", "limit": 4})
    assert response.status_code == 200
    body = response.json()
    assert body["stale"] is True and body["count"] == 4 and body["warnings"]
