"""Test doubles. The candles generated here exist ONLY for tests; the application never fabricates data."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Callable, Optional

from app.market.models import Asset, RawCandle, Timeframe
from app.market.provider import MarketDataProvider


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def make_raw_candles(timeframe: Timeframe, count: int, now: Optional[datetime] = None) -> list[RawCandle]:
    """`count` valid candles ending with the currently forming one, newest first (like Twelve Data)."""
    now = now or utcnow()
    step = timeframe.seconds
    bucket = int(now.timestamp()) // step * step
    rows: list[RawCandle] = []
    for i in range(count):
        ts = bucket - (count - 1 - i) * step
        base = 1.10000 + i * 0.0001
        rows.append(
            RawCandle(
                timestamp=datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                open=f"{base:.5f}",
                high=f"{base + 0.0005:.5f}",
                low=f"{base - 0.0005:.5f}",
                close=f"{base + 0.0002:.5f}",
            )
        )
    return rows[::-1]


class FakeProvider(MarketDataProvider):
    name = "fake"

    def __init__(
        self,
        symbols: tuple[str, ...] = ("EUR/USD", "GBP/USD", "USD/JPY"),
        configured: bool = True,
        clock: Optional[Callable[[], datetime]] = None,
    ) -> None:
        self.symbols = list(symbols)
        self._configured = configured
        self.clock = clock or utcnow
        self.asset_calls = 0
        self.candle_calls = 0
        self.assets_error: Optional[Exception] = None
        self.candles_error: Optional[Exception] = None
        self.rows: Optional[list[RawCandle]] = None
        self.supported_timeframes = frozenset(Timeframe)

    @property
    def is_configured(self) -> bool:
        return self._configured

    async def list_assets(self) -> list[Asset]:
        self.asset_calls += 1
        if self.assets_error:
            raise self.assets_error
        return [
            Asset(symbol=s, base=s.split("/")[0], quote=s.split("/")[1], group="Test", source=self.name)
            for s in self.symbols
        ]

    async def fetch_candles(self, asset: str, timeframe: Timeframe, limit: int) -> list[RawCandle]:
        self.candle_calls += 1
        if self.candles_error:
            raise self.candles_error
        if self.rows is not None:
            return list(self.rows)
        return make_raw_candles(timeframe, limit, now=self.clock())
