"""Provider tests use httpx's MockTransport: no real network traffic and no real API key."""
import asyncio

import pytest

httpx = pytest.importorskip("httpx")

from app.market.models import Timeframe  # noqa: E402
from app.market.provider import (  # noqa: E402
    ProviderAuthError,
    ProviderConfigError,
    ProviderDataError,
    ProviderRateLimitError,
    ProviderRequestError,
    ProviderUnavailableError,
    UnknownAssetError,
)
from app.market.twelvedata import TwelveDataProvider  # noqa: E402

KEY = "test-key-123"

SERIES = {
    "meta": {"symbol": "EUR/USD", "interval": "1min"},
    "values": [
        {"datetime": "2026-11-15 11:59:00", "open": "1.10010", "high": "1.10050", "low": "1.09990", "close": "1.10040"},
        {"datetime": "2026-11-15 11:58:00", "open": "1.10000", "high": "1.10020", "low": "1.09980", "close": "1.10010"},
    ],
    "status": "ok",
}


class Harness:
    """Wires a TwelveDataProvider to a scripted handler and records requests and sleeps."""

    def __init__(self, responses, **kwargs):
        self.responses = list(responses)
        self.requests = []
        self.sleeps = []

        def handler(request):
            self.requests.append(request)
            item = self.responses.pop(0) if len(self.responses) > 1 else self.responses[0]
            if isinstance(item, Exception):
                raise item
            return item

        async def fake_sleep(seconds):
            self.sleeps.append(seconds)

        self.client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        kwargs.setdefault("max_retries", 2)
        kwargs.setdefault("backoff_seconds", 0.5)
        self.provider = TwelveDataProvider(
            kwargs.pop("api_key", KEY), client=self.client, sleep=fake_sleep, **kwargs
        )

    def call(self, coro_factory):
        async def runner():
            try:
                return await coro_factory(self.provider)
            finally:
                await self.client.aclose()

        return asyncio.run(runner())


def ok(payload):
    return httpx.Response(200, json=payload)


def test_fetch_candles_parses_rows_and_sends_auth_header_not_url_key():
    h = Harness([ok(SERIES)])
    rows = h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 2))
    assert [r.timestamp for r in rows] == ["2026-11-15 11:59:00", "2026-11-15 11:58:00"]
    assert rows[0].open == "1.10010" and rows[0].volume is None

    request = h.requests[0]
    assert request.url.path == "/time_series"
    assert request.headers.get("authorization") == f"apikey {KEY}"
    assert KEY not in str(request.url)
    params = request.url.params
    assert params.get("symbol") == "EUR/USD"
    assert params.get("interval") == "1min"
    assert params.get("outputsize") == "2"
    assert params.get("timezone") == "UTC"


@pytest.mark.parametrize(
    "timeframe, interval",
    [(Timeframe.M1, "1min"), (Timeframe.M5, "5min"), (Timeframe.M15, "15min")],
)
def test_interval_mapping(timeframe, interval):
    h = Harness([ok(SERIES)])
    h.call(lambda p: p.fetch_candles("EUR/USD", timeframe, 1))
    assert h.requests[0].url.params.get("interval") == interval


def test_missing_api_key_fails_without_any_request():
    h = Harness([ok(SERIES)], api_key="")
    assert h.provider.is_configured is False
    with pytest.raises(ProviderConfigError):
        h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 1))
    assert h.requests == []


def test_auth_error_is_not_retried_and_does_not_leak_key():
    body = {"code": 401, "message": "apikey parameter is incorrect", "status": "error"}
    h = Harness([httpx.Response(401, json=body)])
    with pytest.raises(ProviderAuthError) as info:
        h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 1))
    assert len(h.requests) == 1
    assert KEY not in str(info.value)


def test_error_in_body_with_http_200_is_detected():
    body = {"code": 403, "message": "plan does not include this", "status": "error"}
    h = Harness([ok(body)])
    with pytest.raises(ProviderAuthError):
        h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 1))


def test_rate_limit_is_retried_with_backoff_then_succeeds():
    limited = httpx.Response(429, json={"code": 429, "message": "too many", "status": "error"})
    h = Harness([limited, limited, ok(SERIES)])
    rows = h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 2))
    assert len(rows) == 2
    assert len(h.requests) == 3
    assert h.sleeps == [0.5, 1.0]


def test_rate_limit_honours_retry_after_header():
    limited = httpx.Response(
        429, headers={"Retry-After": "3"}, json={"code": 429, "message": "x", "status": "error"}
    )
    h = Harness([limited, ok(SERIES)])
    h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 2))
    assert h.sleeps == [3.0]


def test_rate_limit_with_long_retry_after_is_not_waited_out():
    limited = httpx.Response(
        429, headers={"Retry-After": "300"}, json={"code": 429, "message": "x", "status": "error"}
    )
    h = Harness([limited])
    with pytest.raises(ProviderRateLimitError) as info:
        h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 2))
    assert info.value.retry_after == 300
    assert h.sleeps == [] and len(h.requests) == 1


def test_server_errors_exhaust_retries():
    h = Harness([httpx.Response(500, text="boom")])
    with pytest.raises(ProviderUnavailableError):
        h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 1))
    assert len(h.requests) == 3  # first try + 2 retries


@pytest.mark.parametrize(
    "error",
    [httpx.ReadTimeout("slow"), httpx.ConnectError("refused")],
)
def test_network_failures_become_unavailable(error):
    h = Harness([error])
    with pytest.raises(ProviderUnavailableError):
        h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 1))
    assert len(h.requests) == 3


def test_non_json_body_is_a_data_error():
    h = Harness([httpx.Response(200, text="<html>maintenance</html>")])
    with pytest.raises(ProviderDataError):
        h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 1))


def test_payload_without_values_is_a_data_error():
    h = Harness([ok({"status": "ok", "meta": {}})])
    with pytest.raises(ProviderDataError):
        h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 1))


def test_bad_symbol_maps_to_unknown_asset():
    body = {"code": 400, "message": "**symbol** not found: FOO/BAR", "status": "error"}
    h = Harness([httpx.Response(400, json=body)])
    with pytest.raises(UnknownAssetError):
        h.call(lambda p: p.fetch_candles("FOO/BAR", Timeframe.M1, 1))


def test_other_bad_request_maps_to_request_error():
    body = {"code": 400, "message": "outputsize is invalid", "status": "error"}
    h = Harness([httpx.Response(400, json=body)])
    with pytest.raises(ProviderRequestError):
        h.call(lambda p: p.fetch_candles("EUR/USD", Timeframe.M1, 1))


def test_list_assets_parses_dedupes_and_skips_junk():
    payload = {
        "data": [
            {"symbol": "GBP/USD", "currency_group": "Major", "currency_base": "British Pound", "currency_quote": "US Dollar"},
            {"symbol": "EUR/USD", "currency_group": "Major"},
            {"symbol": "EUR/USD", "currency_group": "Major"},
            {"symbol": "not a symbol"},
            "garbage",
        ],
        "status": "ok",
    }
    h = Harness([ok(payload)])
    assets = h.call(lambda p: p.list_assets())
    assert [a.symbol for a in assets] == ["EUR/USD", "GBP/USD"]
    assert assets[0].base == "EUR" and assets[0].quote == "USD"
    assert assets[0].group == "Major" and assets[0].source == "twelvedata"
    assert h.requests[0].url.path == "/forex_pairs"


def test_list_assets_without_data_is_a_data_error():
    h = Harness([ok({"status": "ok"})])
    with pytest.raises(ProviderDataError):
        h.call(lambda p: p.list_assets())


def test_supported_timeframes():
    assert TwelveDataProvider.supported_timeframes == frozenset(Timeframe)
