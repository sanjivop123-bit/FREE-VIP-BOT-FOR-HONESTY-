from datetime import datetime, timedelta, timezone

import pytest

from app.market.models import RawCandle, Timeframe
from app.market.validator import (
    normalize_asset,
    parse_number,
    parse_timestamp,
    validate_candles,
)

NOW = datetime(2026, 11, 15, 12, 0, 30, tzinfo=timezone.utc)


def raw(ts="2026-11-15 11:58:00", o="1.1000", h="1.1010", low="1.0990", c="1.1005", v=None):
    return RawCandle(timestamp=ts, open=o, high=h, low=low, close=c, volume=v)


def run(rows, tf=Timeframe.M1):
    return validate_candles(rows, asset="EUR/USD", timeframe=tf, source="test", now=NOW)


@pytest.mark.parametrize(
    "value, expected",
    [
        ("eur/usd", "EUR/USD"),
        ("EURUSD", "EUR/USD"),
        ("eur-usd", "EUR/USD"),
        (" EUR_USD ", "EUR/USD"),
        ("XAU/USD", "XAU/USD"),
    ],
)
def test_normalize_asset_accepts(value, expected):
    assert normalize_asset(value) == expected


@pytest.mark.parametrize("value", ["", "E", "EUR/USD (OTC)", "EUR/USD/JPY", "EURUS", "../etc", 123, None])
def test_normalize_asset_rejects(value):
    with pytest.raises(ValueError):
        normalize_asset(value)


def test_parse_timestamp_variants_are_utc():
    expected = datetime(2026, 11, 15, 11, 58, tzinfo=timezone.utc)
    assert parse_timestamp("2026-11-15 11:58:00") == expected  # naive -> UTC
    assert parse_timestamp("2026-11-15T11:58:00Z") == expected
    assert parse_timestamp("2026-11-15T17:28:00+05:30") == expected
    assert parse_timestamp(int(expected.timestamp())) == expected
    assert parse_timestamp(str(int(expected.timestamp()) * 1000)) == expected  # milliseconds
    assert parse_timestamp(expected.replace(tzinfo=None)) == expected


@pytest.mark.parametrize("value", [None, "", "yesterday", True, [], "0"])
def test_parse_timestamp_rejects(value):
    with pytest.raises(ValueError):
        parse_timestamp(value)


@pytest.mark.parametrize("value", [None, "", "abc", "nan", "inf", True])
def test_parse_number_rejects(value):
    with pytest.raises(ValueError):
        parse_number(value, "x")


def test_valid_candle_with_string_numbers():
    report = run([raw()])
    assert not report.rejected
    candle = report.valid[0]
    assert (candle.open, candle.high, candle.low, candle.close) == (1.1, 1.101, 1.099, 1.1005)
    assert candle.source == "test"
    assert candle.timestamp == datetime(2026, 11, 15, 11, 58, tzinfo=timezone.utc)
    assert candle.volume is None


def test_volume_is_kept_when_present():
    assert run([raw(v="123.5")]).valid[0].volume == 123.5


@pytest.mark.parametrize(
    "kwargs, reason_part",
    [
        (dict(h="1.0980"), "below low"),
        (dict(h="1.1002", c="1.1005"), "high is below"),
        (dict(low="1.1003"), "low is above"),
        (dict(o="0"), "greater than zero"),
        (dict(c="-1.2"), "greater than zero"),
        (dict(o="abc"), "not numeric"),
        (dict(c="nan"), "not finite"),
        (dict(h=None), "missing"),
        (dict(v="-5"), "negative"),
        (dict(ts="garbage"), "unparseable"),
        (dict(ts="2026-11-15 12:30:00"), "future"),
        (dict(ts="2026-11-15 11:58:30"), "not aligned"),
    ],
)
def test_invalid_candles_are_rejected_with_reason(kwargs, reason_part):
    report = run([raw(**kwargs)])
    assert report.valid == []
    assert len(report.rejected) == 1
    assert reason_part in report.rejected[0].reason


def test_good_rows_survive_alongside_bad_rows():
    report = run([raw("2026-11-15 11:57:00"), raw(o="x"), raw("2026-11-15 11:58:00")])
    assert len(report.valid) == 2
    assert [r.index for r in report.rejected] == [1]


def test_sorted_oldest_first_and_deduplicated():
    rows = [
        raw("2026-11-15 11:59:00"),
        raw("2026-11-15 11:57:00"),
        raw("2026-11-15 11:58:00"),
        raw("2026-11-15 11:58:00", c="1.1008"),  # duplicate timestamp, later one wins
    ]
    report = run(rows)
    assert [c.timestamp.minute for c in report.valid] == [57, 58, 59]
    assert report.valid[1].close == 1.1008


@pytest.mark.parametrize(
    "tf, ts, ok",
    [
        (Timeframe.M5, "2026-11-15 11:55:00", True),
        (Timeframe.M5, "2026-11-15 11:58:00", False),
        (Timeframe.M15, "2026-11-15 11:45:00", True),
        (Timeframe.M15, "2026-11-15 11:50:00", False),
    ],
)
def test_alignment_per_timeframe(tf, ts, ok):
    assert bool(run([raw(ts)], tf).valid) is ok


def test_small_clock_skew_is_tolerated():
    ts = (NOW + timedelta(seconds=60)).replace(second=0).strftime("%Y-%m-%d %H:%M:%S")
    assert run([raw(ts)]).valid
