from datetime import datetime, timedelta, timezone

import pytest

from app.database.storage import SQLiteStorage, StorageError
from app.market.models import Asset, Candle, Timeframe


@pytest.fixture
def storage(tmp_path):
    s = SQLiteStorage(str(tmp_path / "sub" / "t.db"))  # also checks the directory is created
    s.initialize()
    return s


def candle(ts, close=1.1005, asset="EUR/USD", tf=Timeframe.M1, source="test", fetched=None):
    return Candle(
        asset=asset,
        timeframe=tf,
        timestamp=ts,
        open=1.1,
        high=1.101,
        low=1.099,
        close=close,
        source=source,
        fetched_at=fetched or ts,
    )


T0 = datetime(2026, 11, 15, 10, 0, tzinfo=timezone.utc)


def test_initialize_is_idempotent(storage):
    storage.initialize()
    storage.ping()


def test_roundtrip_returns_latest_n_oldest_first(storage):
    storage.upsert_candles([candle(T0 + timedelta(minutes=i)) for i in range(10)])
    got = storage.get_candles("EUR/USD", Timeframe.M1, 3)
    assert [c.timestamp for c in got] == [T0 + timedelta(minutes=i) for i in (7, 8, 9)]
    assert got[0].source == "test"
    assert got[0].timestamp.tzinfo is not None


def test_upsert_updates_existing_candle(storage):
    storage.upsert_candles([candle(T0, close=1.1003)])
    storage.upsert_candles([candle(T0, close=1.1008, source="other")])
    got = storage.get_candles("EUR/USD", Timeframe.M1, 10)
    assert len(got) == 1
    assert got[0].close == 1.1008
    assert got[0].source == "other"


def test_series_are_isolated(storage):
    storage.upsert_candles(
        [
            candle(T0),
            candle(T0, tf=Timeframe.M5),
            candle(T0, asset="GBP/USD"),
        ]
    )
    assert storage.count_candles() == 3
    assert storage.count_candles("EUR/USD", Timeframe.M1) == 1
    assert len(storage.get_candles("GBP/USD", Timeframe.M5, 10)) == 0


def test_closed_only_excludes_forming_candle(storage):
    now = T0 + timedelta(minutes=5, seconds=30)
    storage.upsert_candles([candle(T0 + timedelta(minutes=i)) for i in range(6)])  # last opens at +5m
    all_rows = storage.get_candles("EUR/USD", Timeframe.M1, 10, now=now)
    closed = storage.get_candles("EUR/USD", Timeframe.M1, 10, closed_only=True, now=now)
    assert len(all_rows) == 6
    assert [c.timestamp for c in closed] == [T0 + timedelta(minutes=i) for i in range(5)]


def test_latest_fetched_at(storage):
    assert storage.latest_fetched_at("EUR/USD", Timeframe.M1) is None
    storage.upsert_candles([candle(T0, fetched=T0 + timedelta(seconds=5))])
    assert storage.latest_fetched_at("EUR/USD", Timeframe.M1) == T0 + timedelta(seconds=5)


def test_upsert_empty_is_noop(storage):
    assert storage.upsert_candles([]) == 0
    assert storage.upsert_assets([]) == 0


def test_assets_replace_and_read(storage):
    assert storage.get_assets() == ([], None)
    a = Asset(symbol="EUR/USD", base="EUR", quote="USD", group="Major", source="test")
    b = Asset(symbol="GBP/USD", base="GBP", quote="USD", source="test")
    storage.upsert_assets([b, a], now=T0)
    assets, updated = storage.get_assets()
    assert [x.symbol for x in assets] == ["EUR/USD", "GBP/USD"]
    assert assets[0].group == "Major"
    assert updated == T0
    storage.upsert_assets([a], now=T0 + timedelta(hours=1))
    assets, updated = storage.get_assets()
    assert [x.symbol for x in assets] == ["EUR/USD"]
    assert updated == T0 + timedelta(hours=1)


def test_unusable_path_raises_storage_error(tmp_path):
    blocker = tmp_path / "file"
    blocker.write_text("x")
    with pytest.raises(StorageError):
        SQLiteStorage(str(blocker / "db.sqlite"))
