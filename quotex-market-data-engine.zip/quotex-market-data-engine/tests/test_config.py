import pytest

from app.config import ConfigError, Settings
from app.market.models import Timeframe


def test_defaults():
    s = Settings.from_env({})
    assert s.provider == "twelvedata"
    assert s.twelvedata_api_key is None
    assert s.collector_enabled is False
    assert s.collector_timeframes == (Timeframe.M1, Timeframe.M5, Timeframe.M15)
    assert s.default_candle_limit == 100


def test_values_are_parsed():
    s = Settings.from_env(
        {
            "PROVIDER": "TwelveData",
            "TWELVEDATA_API_KEY": "  abc  ",
            "MAX_RETRIES": "5",
            "REQUEST_TIMEOUT_SECONDS": "2.5",
            "COLLECTOR_ENABLED": "true",
            "COLLECTOR_ASSETS": "eurusd, GBP/USD,EUR/USD",
            "COLLECTOR_TIMEFRAMES": "1m,15m",
            "LOG_LEVEL": "debug",
        }
    )
    assert s.provider == "twelvedata"
    assert s.twelvedata_api_key == "abc"
    assert s.max_retries == 5
    assert s.request_timeout_seconds == 2.5
    assert s.collector_enabled is True
    assert s.collector_assets == ("EUR/USD", "GBP/USD")
    assert s.collector_timeframes == (Timeframe.M1, Timeframe.M15)
    assert s.log_level == "DEBUG"


def test_blank_values_count_as_unset():
    s = Settings.from_env({"TWELVEDATA_API_KEY": "   ", "COLLECTOR_ASSETS": ""})
    assert s.twelvedata_api_key is None
    assert s.collector_assets == ()


def test_all_assets_keyword():
    assert Settings.from_env({"COLLECTOR_ASSETS": "all"}).collector_assets == ("ALL",)


@pytest.mark.parametrize(
    "env",
    [
        {"MAX_RETRIES": "many"},
        {"MAX_RETRIES": "-1"},
        {"REQUEST_TIMEOUT_SECONDS": "0"},
        {"COLLECTOR_ENABLED": "maybe"},
        {"COLLECTOR_TIMEFRAMES": "1h"},
        {"COLLECTOR_ASSETS": "EUR/USD (OTC)"},
        {"LOG_LEVEL": "LOUD"},
        {"DEFAULT_CANDLE_LIMIT": "500", "MAX_CANDLE_LIMIT": "100"},
    ],
)
def test_invalid_values_raise_config_error(env):
    with pytest.raises(ConfigError):
        Settings.from_env(env)
