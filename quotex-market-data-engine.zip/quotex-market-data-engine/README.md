# Quotex Market Data Engine (Step 1)

Market-data collection service for the Quotex Telegram Signals Bot project.
It fetches **real OHLC candles** (1m / 5m / 15m) for forex pairs from a market-data API, validates them, stores them in SQLite and serves them over a small REST API.

**Scope:** data collection only. There is no trading, no order execution and no Quotex integration in this module. It never invents or simulates prices: if the provider is unreachable you get an error, or previously stored candles clearly flagged `"stale": true`.

> **Prices are market reference prices, not Quotex's own feed.** Quotex has no public price API, and its "(OTC)" pairs exist only inside Quotex. Candles from this engine can differ slightly from what Quotex's chart shows. Symbols like `EUR/USD (OTC)` are rejected as invalid.

---

## Build status — read this first

Checked on 2026-11-15 in the build environment, which had **no `fastapi`, no `httpx` and no ability to install packages**:

| Area | Status |
|---|---|
| Validator, SQLite storage, config, collector logic | ✅ 87 automated tests pass |
| Twelve Data provider (retries, error mapping, parsing) | ⚠️ 20 tests pass, but against a **minimal stand-in for `httpx`**, not the real library |
| Endpoint functions in `app/main.py` | ⚠️ exercised through a **minimal FastAPI stub**, not a real server |
| `tests/test_api.py` (real FastAPI `TestClient`) | ❌ **not run** (skipped, dependencies missing) |
| Real `uvicorn` server, Docker build, Android and cloud setups | ❌ **not run** |
| **Live calls to Twelve Data** | ❌ **never tested.** Response shapes follow Twelve Data's documented format, but unconfirmed against the live API |

**Do this once on your machine** (the steps are in "Verify it works" below): `pytest` with the real dependencies installed, then `/health/provider` with your key. Treat live data as working only after `/health/provider` returns `"status": "ok"`.

---

## Architecture

```
Telegram bot / any client
        │  HTTP (REST)
        ▼
   FastAPI  (app/main.py)             endpoints + error → HTTP mapping
        │
        ▼
 MarketCollector (market/collector.py)   fetch → validate → store; caching; background polling
   │            │             │
   ▼            ▼             ▼
Provider     Validator     SQLiteStorage
(provider.py  (validator.py) (database/storage.py)
 + twelvedata.py)
   │
   ▼  HTTPX (async, timeouts, retries with backoff)
Twelve Data REST API
```

```
app/
  main.py                FastAPI app, endpoints, error handlers, lifespan
  config.py              settings from environment / .env
  market/
    models.py            Candle, Asset, Timeframe, response models
    provider.py          MarketDataProvider interface, typed errors, build_provider()
    twelvedata.py        Twelve Data implementation of the interface
    validator.py         symbol normalisation and candle validation
    collector.py         orchestration, caching, background collector
  database/
    storage.py           SQLite (candles + assets)
tests/                   pytest suite (no network, no API key needed)
```

Design rules:

- **Replaceable provider.** Everything outside `twelvedata.py` talks only to the `MarketDataProvider` interface.
- **Validation before storage.** Rejected candles: non-numeric, NaN/inf, price ≤ 0, high < low, high below open/close, low above open/close, future timestamps, timestamps not aligned to the timeframe. Rejects are logged with a reason; if *every* row in a response is rejected the request fails instead of storing anything.
- **Provenance.** Every candle carries `source` (provider name) and `fetched_at`; timestamps are candle **open** times in **UTC**.
- **Quota protection.** Asset list cached (default 1 h); a candle series fetched in the last 10 s is served from SQLite; unknown symbols are rejected locally; 429/5xx/timeouts are retried with backoff; the optional background collector spaces its requests.
- **Graceful degradation.** Provider down + stored data → `200` with `"stale": true` and a warning. Provider down + nothing stored → proper error status.

---

## Quick start (local)

Requires Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt

cp .env.example .env                 # then put your API key into .env
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Interactive docs: http://127.0.0.1:8000/docs

### Verify it works

```bash
pytest                                              # all tests; none need network or a key
curl http://127.0.0.1:8000/health                   # app + database + "is a key configured"
curl http://127.0.0.1:8000/health/provider          # REAL call to Twelve Data (uses 1 credit)
curl "http://127.0.0.1:8000/assets?search=EUR"
curl "http://127.0.0.1:8000/market/candles?asset=EUR/USD&timeframe=1m&limit=5"
```

Live data counts as working only if `/health/provider` returns `{"status": "ok", ...}`. Check that the candle timestamps look current. (Forex is closed on weekends, so the newest candles will be from Friday.)

---

## API key configuration

The default provider is **Twelve Data** (https://twelvedata.com).

1. Create an account at https://twelvedata.com (a free plan exists).
2. Open the dashboard and copy your **API key**.
3. Put it in `.env`: `TWELVEDATA_API_KEY=your_key_here`
4. Restart the service. `GET /health` should show `"provider": {"configured": true}`.

Notes:

- The key is sent in the `Authorization: apikey …` header, never in the URL, and is never logged. Keep `.env` out of git (already in `.gitignore`) and never paste the key into chats or screenshots.
- **Rate limits and available data depend on your plan.** Check your dashboard / pricing page. I could not verify the free-tier numbers or which pairs, intervals and endpoints it includes. If your plan lacks something you will see `provider_auth_failed` (HTTP 403 from the provider) with its message. On `429` the engine retries with backoff, then returns `429` with a `Retry-After` header.
- Each real request costs credits. `/assets` is cached; `/market/candles` makes one provider call per request unless the series was fetched within `CANDLES_CACHE_TTL_SECONDS`.

---

## Endpoints

| Method & path | Purpose |
|---|---|
| `GET /` | Service info and endpoint list |
| `GET /health` | Liveness/readiness: database check + provider-configured flag. No provider call. `200` (ok/degraded), `503` if the database fails |
| `GET /health/provider` | One real provider request; `200` ok or `503` with the error code |
| `GET /assets?search=&refresh=` | Supported pairs from the provider (cached in SQLite) |
| `GET /market/candles?asset=EUR/USD&timeframe=1m` | Candles, oldest first |

`/market/candles` parameters: `asset` (required; `EUR/USD`, `eurusd`, `EUR-USD` all accepted), `timeframe` (`1m` default, `5m`, `15m`), `limit` (default 100, max 1000), `refresh` (default `true`; `false` reads SQLite only), `closed_only` (default `false`; excludes the still-forming candle).

```json
{
  "asset": "EUR/USD",
  "timeframe": "1m",
  "source": "twelvedata",
  "count": 2,
  "stale": false,
  "warnings": [],
  "candles": [
    {"asset": "EUR/USD", "timeframe": "1m", "timestamp": "2026-11-13T21:58:00Z",
     "open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0, "volume": null,
     "source": "twelvedata", "fetched_at": "2026-11-15T12:30:10Z", "is_closed": true}
  ]
}
```
(Prices above are placeholders for illustrating the shape, not market data.)

Things your bot should respect:

- Use `closed_only=true` for signal logic. The newest candle is still changing (`is_closed: false`).
- If `stale` is `true`, the provider could not be reached and the data is older. Check the newest `timestamp`/`fetched_at` and `warnings` before acting.
- `volume` is usually `null` for forex.

Errors use `{"error": {"code": "...", "message": "..."}}`:

| HTTP | code | Meaning |
|---|---|---|
| 400 | `invalid_asset`, `unsupported_timeframe` | Bad input |
| 404 | `unknown_asset` | Provider does not offer that pair |
| 422 | (FastAPI validation) | Bad parameter, or `limit` above the maximum |
| 429 | `provider_rate_limited` | Provider limit reached; see `Retry-After` |
| 502 | `provider_auth_failed`, `provider_request_rejected`, `provider_bad_data` | Provider rejected the key/plan/request, or returned unusable data |
| 503 | `provider_not_configured`, `provider_unavailable` | No API key, or network failure/timeout/5xx |
| 500 | `storage_error` | Database problem |

---

## Configuration

All settings are environment variables (or `.env`); see `.env.example`.

| Variable | Default | Meaning |
|---|---|---|
| `PROVIDER` | `twelvedata` | Which provider implementation to use |
| `TWELVEDATA_API_KEY` | – | Your key (required for any data) |
| `DATABASE_PATH` | `data/market.db` | SQLite file (`/data/market.db` in Docker) |
| `REQUEST_TIMEOUT_SECONDS` | `10` | Per-request timeout |
| `MAX_RETRIES` / `RETRY_BACKOFF_SECONDS` | `3` / `1.0` | Retries on 429/5xx/timeouts; backoff doubles each try |
| `ASSETS_CACHE_TTL_SECONDS` | `3600` | How long the asset list is reused |
| `CANDLES_CACHE_TTL_SECONDS` | `10` | Skip the provider if the series was fetched this recently |
| `DEFAULT_CANDLE_LIMIT` / `MAX_CANDLE_LIMIT` | `100` / `1000` | Candle count limits (max 5000) |
| `COLLECTOR_ENABLED` | `false` | Run the background collector |
| `COLLECTOR_ASSETS` | – | Comma-separated pairs, or `ALL` |
| `COLLECTOR_TIMEFRAMES` | `1m,5m,15m` | Timeframes to poll |
| `COLLECTOR_CYCLE_SECONDS` | `60` | Time between polling passes |
| `COLLECTOR_REQUEST_DELAY_SECONDS` | `8` | Pause between provider requests (stay under per-minute limits) |
| `COLLECTOR_OUTPUTSIZE` | `100` | Candles requested per poll |
| `LOG_LEVEL` | `INFO` | `DEBUG`…`CRITICAL` |

**All pairs:** `/assets` lists every pair the provider offers and `/market/candles` works for any of them. The background collector only needs `COLLECTOR_ASSETS=ALL` if you really want to poll everything. That uses many credits per cycle, so check your plan first.

**Background collector:** each series is polled once per candle period (a 15m series every 15 minutes), so the newest *closed* candle is captured soon after it closes. If the service was down longer than `COLLECTOR_OUTPUTSIZE` candles, there will be a gap. Fill it by requesting a larger `limit` once.

Storage detail: the table key is `(asset, timeframe, timestamp)`; re-fetching a candle updates it in place (this is how the forming candle gets its final values). Each row keeps the `source` that last wrote it.

---

## Docker

```bash
cp .env.example .env        # add your key
docker compose up -d --build
curl http://127.0.0.1:8000/health
```

The compose file stores SQLite in a named volume (`/data`) and publishes the port on `127.0.0.1` only. Run **one** container/worker: SQLite plus the background collector are designed for a single process.

Plain Docker:

```bash
docker build -t quotex-market-data .
docker run -d --name market-data --env-file .env -p 127.0.0.1:8000:8000 -v market_data:/data quotex-market-data
```

---

## Cloud deployment

*(Not tested on any specific platform; these are the generic requirements.)*

**VPS (any Linux server with Docker):**
1. Install Docker, copy the project to the server, create `.env` with your key.
2. `docker compose up -d --build`, then `curl http://127.0.0.1:8000/health` on the server.
3. Let your Telegram bot call `http://127.0.0.1:8000` (same server) or a private network address. If it must be reachable from elsewhere, put a reverse proxy with HTTPS **and authentication** in front (see Security).

**Container platforms (Render, Railway, Fly.io, etc.):**
- Deploy from the `Dockerfile`; set `TWELVEDATA_API_KEY` as a secret in the platform's dashboard, not in the repo.
- Attach a persistent volume mounted at `/data`; without one the database is lost on every restart (candles can be re-fetched, but stored history is gone).
- Run exactly **one instance**; set the health check path to `/health`; listen on port 8000.
- Prefer a private/internal network between the bot and this service. A public URL lets anyone spend your API credits.

---

## Android (Termux)

*(Not tested. Android may stop background apps, so for anything that must run continuously, use a server.)*

1. Install **Termux from F-Droid** (the Play Store build is outdated).
2. **Recommended: run inside a Linux userland**, where normal Python wheels install:
   ```bash
   pkg update && pkg upgrade
   pkg install proot-distro git
   proot-distro install ubuntu
   proot-distro login ubuntu
   apt update && apt install -y python3 python3-venv python3-pip
   ```
   Then copy the project into that environment and follow "Quick start (local)". Check `python3 --version` is 3.11 or newer.
3. *Alternative, native Termux:* `pkg install python rust binutils clang make libffi openssl`, then `pip install -r requirements.txt`. `pydantic-core` has to be compiled there, which is slow and may fail (building it sometimes needs `export ANDROID_API_LEVEL=$(getprop ro.build.version.sdk)` first).
4. Run: `uvicorn app.main:app --host 127.0.0.1 --port 8000` and open `http://127.0.0.1:8000/docs` in the phone's browser.
5. Keep it alive: run `termux-wake-lock`, and exclude Termux from battery optimisation in Android settings.

Docker is not available on Android.

---

## Security

The API has **no authentication** (it is meant to be called by your own bot on the same machine or private network). Do not expose it to the internet as-is: anyone who can reach it can consume your provider quota. Keep it on `127.0.0.1` or a private network, or add HTTPS and authentication in a reverse proxy.

---

## Tests

```bash
pip install -r requirements-dev.txt
pytest
```

The suite needs no network and no API key. The provider is tested with `httpx.MockTransport`, the collector and API with a fake provider. (The generated candles in `tests/fakes.py` exist only for tests; the application never produces data itself.) If `fastapi` or `httpx` is not installed, the API and provider test files are skipped. Run `pytest -rs` to see skips.

---

## Adding or swapping a data provider

1. Create `app/market/yourprovider.py` with a class implementing `MarketDataProvider` (`is_configured`, `list_assets`, `fetch_candles`, optionally `check_connection`/`aclose`). Raise the typed errors from `provider.py` so retries, HTTP status codes and stale-data fallback keep working.
2. Add a branch in `build_provider()` in `provider.py`.
3. Set `PROVIDER=yourprovider`.

Return candles as `RawCandle` values; the validator does the checking. Nothing else needs to change.

---

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| `503 provider_not_configured` | `TWELVEDATA_API_KEY` missing or blank in `.env` |
| `502 provider_auth_failed` | Wrong key, or your plan does not include that pair/interval/endpoint |
| `429 provider_rate_limited` | Plan limit reached; wait, raise `COLLECTOR_REQUEST_DELAY_SECONDS`, or upgrade |
| `502 provider_bad_data` | Provider returned data that failed validation (see logs for the reasons) |
| Old candle timestamps | Forex market closed (weekend), or `"stale": true` |
| `ConfigError` at startup | An environment variable has an invalid value; the message names it |
